(function(){console.log("SubDupes Subscription Prompt Module Loaded");let f=new Set,p=new Set;try{chrome.storage.local.get(["dismissedDomains"],t=>{chrome.runtime.lastError||t.dismissedDomains&&(p=new Set(t.dismissedDomains))})}catch{}function S(t){const e=t.data||{},n={USD:"$",EUR:"€",GBP:"£",INR:"₹",JPY:"¥"}[e.currency]||e.currency||"$",r=e.amount?`${n}${parseFloat(e.amount).toFixed(2)}`:"Detected",d=(e.billingCycle||"MONTHLY").toLowerCase(),a=v=>String(v||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"),i=a(e.name),l=e.planName?` — ${a(e.planName)}`:"",b=e.type||t.type||"SHOW_SUBSCRIPTION_PROMPT";let c="Subscription Detected 🎯",m="Looks like you're about to subscribe. Save it to track and never overpay!",u="💾 Save to SubDupes",y="linear-gradient(135deg, #2563EB 0%, #7C3AED 100%)",g="linear-gradient(135deg, #2563EB 0%, #3B82F6 100%)";return b==="SHOW_ALREADY_SUBSCRIBED_TOAST"?(c="Already Subscribed ✅",m=`You're already tracking <b>${i}</b> at ${n}${parseFloat(e.storedAmount||0).toFixed(2)}/mo.`,u="👀 View in SubDupes",y="linear-gradient(135deg, #10B981 0%, #059669 100%)",g="linear-gradient(135deg, #10B981 0%, #059669 100%)"):b==="SHOW_RECEIPT_IMPORT_PROMPT"&&(c="Receipt Found 📧",m=`Found a receipt for <b>${i}</b>. Import this to your list?`,u="📥 Import Now",y="linear-gradient(135deg, #8B5CF6 0%, #6D28D9 100%)",g="linear-gradient(135deg, #8B5CF6 0%, #6D28D9 100%)"),`
    <div id="subdupes-save-prompt" style="
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 360px;
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15), 0 0 0 1px rgba(0, 0, 0, 0.05);
        z-index: 2147483647;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        overflow: hidden;
        animation: sdPromptSlideIn 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        transform-origin: bottom right;
    ">
        <style>
            @keyframes sdPromptSlideIn {
                from { opacity: 0; transform: translateY(16px) scale(0.96); }
                to { opacity: 1; transform: translateY(0) scale(1); }
            }
            @keyframes sdPromptSlideOut {
                from { opacity: 1; transform: translateY(0) scale(1); }
                to { opacity: 0; transform: translateY(16px) scale(0.96); }
            }
            #subdupes-save-prompt * { box-sizing: border-box; }
            #subdupes-save-prompt button { font-family: inherit; }
        </style>

        <!-- Header Bar -->
        <div style="
            background: ${y};
            padding: 14px 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        ">
            <div style="display: flex; align-items: center; gap: 10px;">
                <div style="
                    width: 28px; height: 28px;
                    background: rgba(255,255,255,0.2);
                    border-radius: 8px;
                    display: flex; align-items: center; justify-content: center;
                    color: white; font-weight: 800; font-size: 13px;
                ">S</div>
                <span style="color: white; font-weight: 700; font-size: 14px; letter-spacing: -0.01em;">SubDupes</span>
            </div>
            <button id="sd-prompt-close" style="
                background: rgba(255,255,255,0.15);
                border: none;
                color: white;
                width: 24px; height: 24px;
                border-radius: 6px;
                cursor: pointer;
                display: flex; align-items: center; justify-content: center;
                font-size: 16px;
                line-height: 1;
                transition: background 0.2s;
            " onmouseover="this.style.background='rgba(255,255,255,0.3)'" onmouseout="this.style.background='rgba(255,255,255,0.15)'">&times;</button>
        </div>

        <!-- Body -->
        <div style="padding: 16px 16px 12px;">
            <div style="font-size: 14px; font-weight: 600; color: #111827; margin-bottom: 4px;">
                ${c}
            </div>
            <p style="font-size: 12px; color: #6B7280; margin: 0 0 14px; line-height: 1.4;">
                ${m}
            </p>

            <!-- Detected Details Card -->
            <div style="
                background: #F8FAFC;
                border: 1px solid #E2E8F0;
                border-radius: 10px;
                padding: 12px;
                margin-bottom: 14px;
            ">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <div style="font-size: 13px; font-weight: 600; color: #1E293B;">${i}${l}</div>
                        <div style="font-size: 11px; color: #94A3B8; margin-top: 2px;">${window.location.hostname}</div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-size: 18px; font-weight: 700; color: #2563EB;">${r}</div>
                        <div style="font-size: 10px; color: #94A3B8; text-transform: uppercase; letter-spacing: 0.5px;">${d}</div>
                    </div>
                </div>
            </div>

            <!-- Actions -->
            <button id="sd-prompt-save" style="
                width: 100%;
                padding: 10px 16px;
                background: ${g};
                color: white;
                border: none;
                border-radius: 10px;
                font-size: 13px;
                font-weight: 600;
                cursor: pointer;
                transition: opacity 0.2s, transform 0.1s;
                letter-spacing: -0.01em;
            " onmouseover="this.style.opacity='0.9'" onmouseout="this.style.opacity='1'" onmousedown="this.style.transform='scale(0.98)'" onmouseup="this.style.transform='scale(1)'">
                ${u}
            </button>

            <div style="display: flex; gap: 8px; margin-top: 8px;">
                <button id="sd-prompt-dismiss" style="
                    flex: 1;
                    padding: 8px;
                    background: #F1F5F9;
                    color: #64748B;
                    border: none;
                    border-radius: 8px;
                    font-size: 11px;
                    font-weight: 500;
                    cursor: pointer;
                    transition: background 0.2s;
                " onmouseover="this.style.background='#E2E8F0'" onmouseout="this.style.background='#F1F5F9'">
                    Dismiss
                </button>
                <button id="sd-prompt-block" style="
                    flex: 1;
                    padding: 8px;
                    background: #F1F5F9;
                    color: #94A3B8;
                    border: none;
                    border-radius: 8px;
                    font-size: 11px;
                    font-weight: 500;
                    cursor: pointer;
                    transition: background 0.2s;
                " onmouseover="this.style.background='#E2E8F0'" onmouseout="this.style.background='#F1F5F9'">
                    Not a subscription
                </button>
            </div>
        </div>

        <!-- Progress bar (auto-dismiss timer) -->
        <div style="height: 3px; background: #F1F5F9; overflow: hidden;">
            <div id="sd-prompt-timer-bar" style="
                height: 100%;
                width: 100%;
                background: linear-gradient(90deg, #2563EB, #7C3AED);
                transition: width 15s linear;
            "></div>
        </div>
    </div>
    `}let x=null;function h(t){t.data;const e=t.type||"SHOW_SUBSCRIPTION_PROMPT";if(f.has(e)||p.has(window.location.hostname)||document.getElementById("subdupes-save-prompt"))return;f.add(e);const o=document.createElement("div");o.id="subdupes-prompt-container",o.innerHTML=S(t),document.body.appendChild(o),requestAnimationFrame(()=>{const n=document.getElementById("sd-prompt-timer-bar");n&&(n.style.width="0%")}),x=setTimeout(()=>{s()},15e3),P(t)}function s(){clearTimeout(x);const t=document.getElementById("subdupes-save-prompt");t&&(t.style.animation="sdPromptSlideOut 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards",setTimeout(()=>{const e=document.getElementById("subdupes-prompt-container");e&&e.remove()},300))}function P(t){const e=t.data||{},o=e.type||t.type||"SHOW_SUBSCRIPTION_PROMPT",n=document.getElementById("sd-prompt-close");n&&n.addEventListener("click",s);const r=document.getElementById("sd-prompt-save");r&&r.addEventListener("click",()=>{if(o==="SHOW_ALREADY_SUBSCRIBED_TOAST"){try{chrome.runtime.sendMessage({type:"OPEN_POPUP"})}catch{}s();return}const i={name:e.name,planName:e.planName||"",amount:parseFloat(e.amount)||null,currency:e.currency||"USD",billingCycle:e.billingCycle||"MONTHLY",websiteUrl:e.websiteUrl||window.location.origin,source:o==="SHOW_RECEIPT_IMPORT_PROMPT"?"GMAIL_IMPORT":"PROACTIVE_PROMPT",detectedAt:new Date().toISOString()};try{chrome.runtime.sendMessage({type:"SAVE_FROM_PROMPT",data:i},l=>{chrome.runtime.lastError&&console.warn("Save message failed:",chrome.runtime.lastError.message)})}catch(l){console.warn("Failed to send save message:",l)}r.textContent="✓ Done!",r.style.background="linear-gradient(135deg, #059669 0%, #10B981 100%)",setTimeout(()=>s(),1500)});const d=document.getElementById("sd-prompt-dismiss");d&&d.addEventListener("click",s);const a=document.getElementById("sd-prompt-block");a&&a.addEventListener("click",()=>{const i=window.location.hostname;p.add(i);try{chrome.storage.local.set({dismissedDomains:Array.from(p)})}catch{}s()})}chrome.runtime.onMessage.addListener((t,e,o)=>{(t.type==="SHOW_SUBSCRIPTION_PROMPT"||t.type==="SHOW_ALREADY_SUBSCRIBED_TOAST"||t.type==="SHOW_RECEIPT_IMPORT_PROMPT")&&h(t)});window.addEventListener("subdupes-prompt-ready",t=>{t.detail&&h({type:"SHOW_SUBSCRIPTION_PROMPT",data:t.detail})});
})()