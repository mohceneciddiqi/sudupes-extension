export const VIEWS = {
    AUTH: 'auth',
    DASHBOARD: 'dashboard',
    ADD_DRAFT: 'add-draft',
    ALL_SUBSCRIPTIONS: 'all-subscriptions',
};
